**********************
The config module
**********************

.. automodule:: pyamp.config


The Option class
-------------------------

.. autoclass:: pyamp.config.Option
   :members:


The ClOption class
-------------------------

.. autoclass:: pyamp.config.ClOption
   :members:


The ConfigFile class
-------------------------

.. autoclass:: pyamp.config.ConfigFile
   :members:


The OptionsParser class
-------------------------

.. autoclass:: pyamp.config.OptionsParser
   :members:


The conversions module
-------------------------

.. automodule:: pyamp.config.conversions
   :members:
