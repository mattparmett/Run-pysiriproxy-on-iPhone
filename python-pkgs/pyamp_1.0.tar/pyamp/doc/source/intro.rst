================================================================================
Introduction
================================================================================

----------------------------------------
About
----------------------------------------

The pyamp module is a Python module which attempts to provide generic
implementations for common tasks which can be reused throughout many
applications.

pyamp is still in the early development stages, and is by no means complete.

----------------------------------------
Licensing
----------------------------------------

pyamp is is covered by the
`GNU General Public License v3.0 <https://www.gnu.org/licenses/>`, Below is the
license:

    pyamp. Copyright 2012 Brett Ponsler

    pyamp is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    pyamp is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with pyamp.  If not, see <http://www.gnu.org/licenses/>.
