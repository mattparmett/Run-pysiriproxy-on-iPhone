**********************
The system module
**********************

.. automodule:: pyamp.system


The ubuntu module
---------------------

.. automodule:: pyamp.system.ubuntu


The Menu class
****************

.. autoclass:: pyamp.system.ubuntu.Menu
   :members:
