**********************
The processes module
**********************

.. automodule:: pyamp.processes


The coroutine function
------------------------

.. autofunction:: pyamp.processes.coroutine

The Thread class
---------------------

.. autoclass:: pyamp.processes.Thread
   :members:

The Cycle class
---------------------

.. autoclass:: pyamp.processes.Cycle
   :members:
