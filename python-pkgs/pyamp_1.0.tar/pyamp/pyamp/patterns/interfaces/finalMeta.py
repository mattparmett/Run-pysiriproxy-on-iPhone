# Copyright 2012 Brett Ponsler
# This file is part of pyamp.
#
# pyamp is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pyamp is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with pyamp.  If not, see <http://www.gnu.org/licenses/>.
'''Contains functions and classes for creating a metaclass to tag specific
methods of a class as 'final', meaning they cannot be overridden by
subclasses of any class that uses this metaclass.

'''


def finalFn():
    '''Define an empty function for use when defining the functions which
    should be tagges as final. This is simply a function that takes no
    arguments and does not do anything. It is merely a place holder for the
    FinalMeta class to realize that it is a function that should not be
    overridden.

    '''
    pass


class FinalMeta(type):
    '''The FinalMeta class implements a metaclass which provides the
    ability to disallow subclasses from overriding a set of functions.
    If the class defines one of these functions an Exception will be raised.

    The FinalMeta has a property called :func:`finalFunctionsClass` which takes
    the name of the class which implements the functions that should not be
    allowed to be overridden by a class using this metaclass.

    This metaclass also provides the 'allowableFunctions' property which
    defines the names of functions which are allowed to be defined.

    Example::

        # Define the class which contains all of the final functions
        class FinalFunctions:
            function1 = finalFn
            function2 = finalFn


        # Define the base metaclass which uses the FinalFunctions defined above
        class ExampleMeta(FinalMeta):
            finalFunctionsClass = FinalFunctions
            allowableFunctions = ["__str__"]


        # Finally define the base class which uses the metaclass defined
        # above, and defines some example functions
        class Example:
            __metaclass__ = ExampleMeta

            # Definining this function will throw an Exception!
            def __init__(self):
                pass

            # Definining this function will throw an Exception!
            def function1(self):
                pass

            # Definining this function will throw an Exception!
            def function2(self):
                pass

            # Defining this function will **not** throw an Exception!
            def __str__(self):
                return ""

    '''
    finalFunctionsClass = object()
    '''The finalFunctionsClass property contains the class which defines all
    of the functions that are final, i.e., not allowed to be overridden by a
    subclass.

    '''

    allowableFunctions = []
    '''The allowableFunctions property defines the list of function names that
    are allowed to be overridden by subclasses.

    '''

    def __new__(mcs, className, parents, attrs):
        '''
        * className -- The name of the class
        * parents -- The parents for the class
        * attrs -- The attributes for the class

        '''
        # Determine the list of final functions from the final functions class
        finalFunctions = mcs.__getFinalFunctions()

        # Grab the list of final functions, and then determine if any of the
        # final functions have been overridden
        functions = mcs.__getFunctionsFromAttrs(attrs)

        # If any of the class functions are found in the list of final
        # functions, then throw an exception because this function is not
        # allowed to be overridden
        for functionName in functions:
            if functionName in finalFunctions:
                raise Exception("The %s function is not allowed to be " \
                                    "overridden" % functionName)

        return type.__new__(mcs, className, parents, attrs)

    @classmethod
    def __getFinalFunctions(mcs):
        '''Get a list of the final functions.

        '''
        # Get the attributes for the final functions class, and then get
        # the list of functions from the attributes dictionary
        attrs = mcs.__getAttrs(mcs.finalFunctionsClass)
        functions = mcs.__getFunctionsFromAttrs(attrs)

        # Filter out all any functions that are found in the list of allowable
        # functions, since it is acceptable for them to be overridden
        functions = [name for name in functions \
                         if name not in mcs.allowableFunctions]

        return functions

    @classmethod
    def __getAttrs(mcs, obj):
        '''For the given object, get a dictionary of attribute names mapped to
        the corresponding attributes.

        * obj -- The object

        '''
        attrNames = dir(obj)
        attrs = [getattr(obj, name, None) for name in attrNames]

        return dict(zip(attrNames, attrs))

    @classmethod
    def __getFunctionsFromAttrs(mcs, attrs):
        '''Get a list of functions for this class from the dictionary of
        attributes for this class.

        * attrs -- The dictionary of attributes

        '''
        functions = []
        for attrName, attr in attrs.iteritems():
            if hasattr(attr, "__call__"):
                functions.append(attrName)

        return functions
