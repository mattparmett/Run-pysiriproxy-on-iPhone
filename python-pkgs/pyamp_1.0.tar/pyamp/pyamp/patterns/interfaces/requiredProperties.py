# Copyright 2012 Brett Ponsler
# This file is part of pyamp.
#
# pyamp is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pyamp is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with pyamp.  If not, see <http://www.gnu.org/licenses/>.
'''The requiredProperties module contains a class which provides
an interface which allows a class to define a set of properties
which the subclasses are required to define. This class handles
checking that each of those required properties are defined and
throwing an error in the event that one of them is not defined.

'''
from pyamp.exceptions import UndefinedPropertyError


class RequiredProperties:
    '''The RequiredProperties class provides an interface which allows
    subclasses to define a set of properties that must be defined for
    that class.

    This class checks that all of those properties are defined, and if
    one of them is not defined this class throws an exception.

    '''
    _RequiredProperties = []
    '''The set of properties that are required to be defined.

    .. note:: Subclasses should set this property to the list of
       properties that are required for the particular class.

    '''

    def  __init__(self):
        '''Check that all the required properties are defined.'''
        self.__checkRequiredProperties()

    ##### Private functions #####

    def __checkRequiredProperties(self):
        '''Check that all of the required properties are defined and
        throw an error in the event if any are not defined.

        '''
        for name in self._RequiredProperties:
            if not hasattr(self, name):
                raise UndefinedPropertyError(self, name)
