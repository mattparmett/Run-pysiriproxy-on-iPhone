# Copyright 2012 Brett Ponsler
# This file is part of pyamp.
#
# pyamp is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pyamp is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with pyamp.  If not, see <http://www.gnu.org/licenses/>.
'''The page module contains the definition of the BasePage class
which provides the base functionality for implementing a page that
can be served by an HTTP server.

This module also contains other classes for defining various types
of pages.

'''
import json

from pyamp.web.http.headers import Header
from pyamp.exceptions import UndefinedPropertyError, UndefinedFunctionError


class BasePage:
    '''The BasePage class contains the basic functionality that is shared
    among all pages.

    '''

    contentType = None
    '''The contentType property contains the type of content contained
    in this Page.

    '''

    def __init__(self):
        '''Create the page.'''
        if self.contentType is None:
            raise UndefinedPropertyError(self, "contentType")

    def get(self, path, arguments):
        '''Get the page.

        * path -- The requested path
        * arguments -- The request arguments dictionary

        '''
        return self._getContent(path, arguments)

    def _getContent(self, _path, _arguments):
        '''Get the content for the Page.

        * _path -- The requested path
        * _arguments -- The request arguments dictionary

        '''
        raise UndefinedFunctionError(self, "_getContent")


class HtmlPage(BasePage):
    '''The HtmlPage class provides a base class that returns
    a page containing text/html content.

    '''

    contentType = Header.textHtmlContent()
    '''Define the content type for the HtmlPage.'''


class JsonPage(BasePage):
    '''The HtmlPage class provides a base class that returns
    a page containing JSON content.

    '''

    contentType = Header.jsonContent()
    '''Define the content type for the JsonPage.'''

    def get(self, path, arguments):
        '''Override the get method to return JSON data.

        * path -- The requested path
        * arguments -- The request arguments dictionary

        '''
        content = self._getContent(path, arguments)
        return json.dumps(content)
