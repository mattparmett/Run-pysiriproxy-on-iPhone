# Copyright 2012 Brett Ponsler
# This file is part of pyamp.
#
# pyamp is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# pyamp is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with pyamp.  If not, see <http://www.gnu.org/licenses/>.
'''The requests module contains classes pertaining to creating
various types of objects to handle HTTP requests.

'''
from urllib import unquote
from BaseHTTPServer import BaseHTTPRequestHandler

from pyamp.util import getStackTrace
from pyamp.web.http.constants import StatusCodes


class BaseRequestHandler(BaseHTTPRequestHandler):
    '''The BaseRequestHandler class provides the basic functionality that
    is shared among all HTTP request handlers.

    '''
    pages = {}
    '''The pages property contains the dictionary of pages that this
    request handler is able to retrieve.

    '''

    # @todo: add default error pages
    errorPages = {}
    '''The errorPages property contains the dictionary mapping error codes
    to the pages to display for those particular errors.

    '''

    def do_GET(self):
        '''Process a GET request.'''
        errorCode = None
        content = None

        # Get the path and the arguments for this request
        path, arguments = self.__getPathAndArguments()

        # Attemp to display the requested page
        page = self.__findPage(path)
        if page is not None:
            try:
                # Request the page with the path, and arguments
                #page.get(self.headers, arguments)
                content = page.get(path, arguments)
            except Exception, e:
                self.log_message(getStackTrace(), e)
                errorCode = StatusCodes.InternalServerError

        if errorCode is None and content is None:
            errorCode = StatusCodes.FileNotFound

        # Display an error page if an error was encountered
        if errorCode is not None:
            page = self.__findErrorPage(errorCode)
            if page is not None:
                content = page.get(path, arguments)
            else:
                self.log_message("Unable to locate error page for [%s]" % \
                                     errorCode)

        # @todo: if page is None here OR it is not initialized, then use a
        # backup Not-found page
        if page is not None and content is not None:
            self.__sendResponse(page, content, errorCode)

    def do_POST(self):
        '''Process a POST request.'''
        # @todo: complete this function
        pass

    def log_message(self, format, *args):
        '''Log a message.

        * format -- The message format
        * args -- The message arguments

        '''
        # @todo: use a logger, or log level here
        BaseHTTPRequestHandler.log_message(self, format, *args)

    def __getPathAndArguments(self):
        '''Get the actual path name, and a dictionary of the arguments
        passed in the path.

        '''
        # Unquote the path to get rid of http encoding
        path = unquote(self.path)
        arguments = {}

        # Find the start of the URL arguments
        if path.find("?") != -1:
            path, strArguments = path.split("?")

            # Add each argument to the argument dictionary
            for argument in strArguments.split("&"):
                if argument.find("=") != -1:
                    name, value = argument.split("=")

                    # Note: Convert all argument names to lowercase
                    arguments[name.lower()] = self.__cleanHtml(value)

        return path, arguments

    @classmethod
    def __cleanHtml(cls, value):
        '''Clean the given HTML string.

        * value -- The HTML string

        '''
        # All the strings with their respective replacements
        replacements = {
            "+": " "
            }

        # Replace all of the strings in the replacement dictionary
        for match, replacement in replacements.iteritems():
            value = value.replace(match, replacement)

        return value

    def __findPage(self, path):
        '''Find a page with the given path.

        * path -- The path for the page

        '''
        return self.pages.get(path)

    def __findErrorPage(self, errorCode):
        '''Find an error page with the given error code.

        * errorCode -- The error code for the page

        '''
        return self.errorPages.get(errorCode)

    def __sendResponse(self, page, content, statusCode):
        '''Send the response for the current request.

        * page -- The page to return
        * content -- The page content to return
        * statusCode -- The status code to return

        '''
        statusCode = StatusCodes.OK if statusCode is None else statusCode

        # Write the status code
        self.send_response(statusCode)

        # Write all of the page headers
        headers = [page.contentType]
        for header in [header for header in headers if header is not None]:
            self.send_header(header.getId(), header.getValue())
        self.end_headers()

        # Finally write the page data
        self.wfile.write(content)


class StoppableRequestHandler(BaseHTTPRequestHandler):
    '''The StoppableRequestHandler class provides an implementation of
    an HTTP request handler that handles the quit message send by a
    server when it is trying to stop itself.

    '''

    def do_QUIT(self):
        '''Handle a QUIT message.'''
        self.send_response(200)
        self.end_headers()
