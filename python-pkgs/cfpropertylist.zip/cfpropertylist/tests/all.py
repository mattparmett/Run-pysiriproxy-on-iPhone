import unittest

from test_array import *
from test_boolean import *
from test_data import *
from test_dictionary import *
from test_file import *
from test_integer import *
from test_offsets import *
from test_real import *
from test_string import *

if __name__ == '__main__':
    unittest.main()
